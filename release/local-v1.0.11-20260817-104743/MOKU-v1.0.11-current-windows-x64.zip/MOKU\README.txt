MOKU for Windows

Requirements:
- Windows 10 or Windows 11, x64
- Microsoft Edge WebView2 Runtime
- Network access to www.pixiv.net and i.pximg.net

Version: 1.0.11

Run MOKU.exe. No Python installation is required.
MOKU starts a loopback-only backend and opens the interface in its own WebView2 desktop window.
Use the built-in Usage Guide button for the offline guide and the explicit anonymous network check.
MOKU can use the target computer's enabled local Windows HTTP system proxy; TUN mode is not required.
If both the system proxy and TUN are off and direct Pixiv access is blocked, search cannot connect.
MOKU never changes Windows proxy settings, starts a VPN, or scans local ports.
Separate multiple tags with ; or 锛?for strict AND matching. Optional bounded tag aliases are disabled by default. Three later pages of result data are prefetched, but unopened-page thumbnails are not downloaded; old pages and temporary preview authorization are released outside the retained window.
Use pid:<artwork ID> for one exact work, uid:<user ID> for one creator, or author:<exact name>. Search options are applied only after Start Search is pressed, and an active search can be cancelled explicitly.
The collection basket accepts any number of artworks within a 1,000 selected-image limit and sends image-first bounded download chunks. A batch is stored in one shared tag, author, or artwork context folder unless folder creation is disabled.
Pixiv authorization opens as a second MOKU desktop window on the official Pixiv website.
The "keep me signed in" option stores only PHPSESSID in Windows Credential Manager for the current Windows user.
Downloads and logs are written beside MOKU.exe. Do not expose the backend to LAN or the Internet.
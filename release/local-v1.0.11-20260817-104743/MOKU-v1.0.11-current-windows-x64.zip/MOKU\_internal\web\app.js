let items = [];
let activeArtworkId = null;
let currentPage = 1;
let pageNumbers = [1];
let firstAvailablePage = 1;
let preloadedThrough = 1;
let searchHasMore = false;
let activeTagQuery = "猫耳";
let searchController = null;
let activeSearchRequestId = null;
let searchRequestSequence = 0;
let detailController = null;
let requestToken = null;
let requestTokenPromise = null;
let requestTokenController = null;
let viewGeneration = 0;
let lockedDeckPage = null;
let pendingNavigationPage = null;
let activeSearchContext = { kind: "tags", value: "猫耳" };
let activeSearchFilters = { mode: "safe", workType: "all", includeAi: false, fuzzy: false };
let currentDetailItem = null;
let currentDetailContext = null;
let collectionPageOffset = 0;
let batchCandidateItems = [];
let basketDetailItem = null;
let basketLockedDeckPage = null;
let basketReturnMode = "summary";
let basketSelectionLocked = false;
let basketArtworkOffset = 0;
let viewerPageOffset = 0;
let paginationDockFrame = null;
let searchPending = false;
let resultSelectionEnabled = false;
let singleDownloadPending = false;
let resumableBatchTask = null;
let lastKnownLoggedIn = null;
let authStatusGeneration = 0;
const batchCandidateContextByArtwork = new Map();
const batchCandidateResultPageByArtwork = new Map();
const MAX_SELECTED_PAGES = 1000;
const DOWNLOAD_CHUNK_ARTWORKS = 20;
const DOWNLOAD_CHUNK_PAGES = 200;
const DETAIL_PAGE_WINDOW = 48;
const DETAIL_REFRESH_COOLDOWN_MS = 30000;
const BASKET_ARTWORK_WINDOW = 120;
const VIEWER_PAGE_WINDOW = 80;
const SEARCH_KEEP_BEHIND = 6;
const detailRefreshes = new Map();
const detailRefreshAttempts = new Map();
const staleBasketPreviewIds = new Set();
const selectedArtworkIds = new Set();
const selectedArtworks = new Map();
const selectedPagesByArtwork = new Map();
const selectedContextByArtwork = new Map();
const selectedResultPageByArtwork = new Map();
const archivedArtworkIds = new Set();

const $ = (selector) => document.querySelector(selector);
const grid = $("#grid");
const gallery = $("#gallery");
const searchButton = $("#searchSubmit");
const cancelSearchButton = $("#cancelSearch");
document.documentElement.classList.add("conservative");

function readSearchFilters() {
  return {
    mode: $("#safety").value || "safe",
    workType: $("#workType").value || "all",
    includeAi: Boolean($("#includeAi").checked),
    fuzzy: Boolean($("#fuzzySearch")?.checked),
  };
}

const esc = (value) => String(value).replace(
  /[&<>"']/g,
  (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char],
);

function announceToast(message) {
  // The basket page covers #detail, so shared flows report in both places.
  $("#toast").textContent = message;
  $("#basketToast").textContent = message;
}

let taskDockTimer = null;
function showTaskDock(title, text, holdMs = 3200) {
  $("#taskDockTitle").textContent = title;
  $("#taskDockText").textContent = text;
  $("#taskDock").classList.add("is-visible");
  if (taskDockTimer) clearTimeout(taskDockTimer);
  taskDockTimer = holdMs > 0
    ? setTimeout(() => {
        taskDockTimer = null;
        $("#taskDock").classList.remove("is-visible");
      }, holdMs)
    : null;
}

async function getRequestToken() {
  if (requestToken) return requestToken;
  if (!requestTokenPromise) {
    const controller = new AbortController();
    requestTokenController = controller;
    const timer = setTimeout(() => controller.abort(), 5000);
    let pending;
    pending = fetch("/api/health", {
      cache: "no-store",
      headers: { "Sec-Fetch-Site": "same-origin" },
      signal: controller.signal,
    })
      .then((response) => {
        if (!response.ok) throw new Error("本机服务未准备好");
        return response.json();
      })
      .then((data) => {
        if (data.protocolVersion !== 5 || data.applicationId !== "MOKU.PixivTagGallery") throw new Error("MOKU 后端版本过旧，请关闭当前窗口并重新启动 MOKU");
        if (!data.requestToken) throw new Error("本机请求授权未初始化");
        requestToken = data.requestToken;
        return requestToken;
      })
      .catch((error) => {
        if (controller.signal.aborted) throw new Error("本机服务连接超时或已取消");
        throw error;
      })
      .finally(() => {
        clearTimeout(timer);
        if (requestTokenController === controller) requestTokenController = null;
        if (!requestToken && requestTokenPromise === pending) requestTokenPromise = null;
      });
    requestTokenPromise = pending;
  }
  return requestTokenPromise;
}

function waitForPromiseOrAbort(promise, signal) {
  if (!signal) return Promise.resolve(promise);
  if (signal.aborted) return Promise.reject(signal.reason || new Error("请求已取消"));
  return new Promise((resolve, reject) => {
    const finish = (callback) => (value) => {
      signal.removeEventListener("abort", abort);
      callback(value);
    };
    const abort = () => reject(signal.reason || new Error("请求已取消"));
    signal.addEventListener("abort", abort, { once: true });
    Promise.resolve(promise).then(finish(resolve), finish(reject));
  });
}

async function fetchJson(url, options = {}, timeoutMs = 12000) {
  const controller = new AbortController();
  const upstream = options.signal;
  let timedOut = false;
  const relayAbort = () => controller.abort(upstream.reason);

  if (upstream) {
    if (upstream.aborted) relayAbort();
    else upstream.addEventListener("abort", relayAbort, { once: true });
  }

  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  try {
    const headers = new Headers(options.headers || {});
    headers.set(
      "X-MOKU-Request-Token",
      await waitForPromiseOrAbort(getRequestToken(), controller.signal),
    );
    const response = await fetch(url, { ...options, headers, signal: controller.signal });
    const text = await response.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      throw new Error("服务返回了无法解析的数据");
    }
    if (!response.ok) throw new Error(data.error || `请求失败（HTTP ${response.status}）`);
    return data;
  } catch (error) {
    if (timedOut) throw new Error("请求超时，请检查 VPN / 系统代理后重试");
    throw error;
  } finally {
    clearTimeout(timer);
    if (upstream) upstream.removeEventListener("abort", relayAbort);
  }
}

function nextSearchRequestId() {
  searchRequestSequence += 1;
  return `${Date.now().toString(36)}-${searchRequestSequence.toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

async function notifySearchCancellation(requestId) {
  if (!requestId || !requestToken) return;
  try {
    await fetch("/api/pixiv/search/cancel", {
      method: "POST",
      cache: "no-store",
      keepalive: true,
      headers: {
        "Content-Type": "application/json",
        "X-MOKU-Request-Token": requestToken,
      },
      body: JSON.stringify({ requestId }),
    });
  } catch {
    // The local service may already be closing; the browser request is still aborted below.
  }
}

function cancelActiveSearch() {
  if (!searchController) return false;
  const requestId = activeSearchRequestId;
  searchController.abort();
  void notifySearchCancellation(requestId);
  return true;
}

function abortDetailRefreshes() {
  detailRefreshes.forEach((entry) => entry.controller.abort());
  detailRefreshes.clear();
  detailRefreshAttempts.clear();
}

async function refreshArtworkPreview(rawArtworkId) {
  const artworkId = String(rawArtworkId || "");
  if (!/^\d+$/.test(artworkId)) return false;
  const existing = detailRefreshes.get(artworkId);
  if (existing) return existing.promise;
  const now = Date.now();
  const lastAttempt = detailRefreshAttempts.get(artworkId) || 0;
  if (now - lastAttempt < DETAIL_REFRESH_COOLDOWN_MS) return false;
  detailRefreshAttempts.set(artworkId, now);
  const controller = new AbortController();
  const generation = viewGeneration;
  let task;
  task = (async () => {
    try {
      const fresh = await fetchJson(`/api/pixiv/artwork/${artworkId}`, { signal: controller.signal }, 18000);
      if (
        controller.signal.aborted
        || generation !== viewGeneration
        || String(activeArtworkId || "") !== artworkId
        || String(fresh?.id || "") !== artworkId
        || !Array.isArray(fresh.pageImages)
      ) return false;

      const itemIndex = items.findIndex((item) => String(item.id) === artworkId);
      if (itemIndex >= 0) items[itemIndex] = fresh;
      const candidateIndex = batchCandidateItems.findIndex((item) => String(item.id) === artworkId);
      if (candidateIndex >= 0) batchCandidateItems[candidateIndex] = fresh;
      if (selectedArtworkIds.has(artworkId)) selectedArtworks.set(artworkId, fresh);
      currentDetailItem = fresh;
      staleBasketPreviewIds.delete(artworkId);

      document.querySelectorAll("[data-detail-artwork]").forEach((img) => {
        if (String(img.dataset.detailArtwork || "") !== artworkId) return;
        const page = Number(img.dataset.detailPage);
        const source = fresh.pageImages?.[page]?.regular || (page === 0 ? fresh.thumb : "");
        if (!source) return;
        delete img.dataset.detailRefreshAttemptedUrl;
        img.classList.remove("image-unavailable");
        img.closest(".page-select,.deck-card,figure")?.classList.remove("image-unavailable");
        img.setAttribute("src", source);
      });
      announceToast("预览授权已刷新");
      return true;
    } catch (error) {
      if (!controller.signal.aborted && generation === viewGeneration) {
        announceToast(error.message || "预览刷新失败");
      }
      return false;
    } finally {
      if (detailRefreshes.get(artworkId)?.promise === task) detailRefreshes.delete(artworkId);
    }
  })();
  detailRefreshes.set(artworkId, { controller, promise: task });
  return task;
}

function installImageFallbacks(root = document) {
  root.querySelectorAll("img").forEach((img) => {
    if (img.dataset.fallbackReady === "1") return;
    img.dataset.fallbackReady = "1";
    img.addEventListener("error", async () => {
      const artworkId = img.dataset.detailArtwork;
      const basketArtworkId = img.dataset.basketArtwork;
      const failedUrl = img.currentSrc || img.getAttribute?.("src") || img.src || "";
      if (artworkId && failedUrl && img.dataset.detailRefreshAttemptedUrl !== failedUrl) {
        img.dataset.detailRefreshAttemptedUrl = failedUrl;
        if (await refreshArtworkPreview(artworkId)) return;
      }
      img.removeAttribute("src");
      img.classList.add("image-unavailable");
      if (basketArtworkId) staleBasketPreviewIds.add(String(basketArtworkId));
      img.closest(".poster,.batch-collection,.page-select,.deck-card,figure")?.classList.add("image-unavailable");
    });
  });
}

const UGOIRA_PREVIEW_CACHE_LIMIT = 6;
const ugoiraPreviewCache = new Map();
let ugoiraPlayer = null;

async function fetchBytes(url, timeoutMs = 30000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const headers = new Headers();
    headers.set("X-MOKU-Request-Token", await getRequestToken());
    const response = await fetch(url, { headers, signal: controller.signal });
    if (!response.ok) throw new Error(`请求失败（HTTP ${response.status}）`);
    return await response.arrayBuffer();
  } catch (error) {
    if (controller.signal.aborted) throw new Error("动图预览加载超时");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function parseZipEntries(buffer) {
  const view = new DataView(buffer);
  let eocd = -1;
  for (let index = view.byteLength - 22; index >= 0; index -= 1) {
    if (view.getUint32(index, true) === 0x06054b50) { eocd = index; break; }
  }
  if (eocd < 0) throw new Error("动图数据已损坏");
  const count = view.getUint16(eocd + 10, true);
  const decoder = new TextDecoder();
  let offset = view.getUint32(eocd + 16, true);
  const entries = new Map();
  for (let index = 0; index < count; index += 1) {
    if (view.getUint32(offset, true) !== 0x02014b50) throw new Error("动图数据已损坏");
    const method = view.getUint16(offset + 10, true);
    const compressedSize = view.getUint32(offset + 20, true);
    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const localOffset = view.getUint32(offset + 42, true);
    entries.set(decoder.decode(new Uint8Array(buffer, offset + 46, nameLength)), { method, compressedSize, localOffset });
    offset += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
}

async function inflateZipEntry(buffer, entry) {
  const view = new DataView(buffer);
  if (view.getUint32(entry.localOffset, true) !== 0x04034b50) throw new Error("动图数据已损坏");
  const nameLength = view.getUint16(entry.localOffset + 26, true);
  const extraLength = view.getUint16(entry.localOffset + 28, true);
  const start = entry.localOffset + 30 + nameLength + extraLength;
  const compressed = buffer.slice(start, start + entry.compressedSize);
  if (entry.method === 0) return compressed;
  if (entry.method === 8) {
    if (typeof DecompressionStream !== "function") throw new Error("当前 WebView 不支持动图预览");
    const stream = new Blob([compressed]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return await new Response(stream).arrayBuffer();
  }
  throw new Error("动图数据使用了不支持的压缩方式");
}

function loadUgoiraFrames(artworkId) {
  const cached = ugoiraPreviewCache.get(artworkId);
  if (cached) return cached;
  const task = (async () => {
    if (typeof createImageBitmap !== "function") throw new Error("当前 WebView 不支持动图预览");
    const meta = await fetchJson(`/api/pixiv/ugoira/${artworkId}`);
    const buffer = await fetchBytes(`/api/pixiv/ugoira/${artworkId}?mode=zip`);
    const entries = parseZipEntries(buffer);
    const frames = [];
    for (const frame of meta.frames || []) {
      const entry = entries.get(frame.file);
      if (!entry) continue;
      const raw = await inflateZipEntry(buffer, entry);
      // ImageBitmap decoding bypasses the strict CSP, which blocks blob: URLs.
      const bitmap = await createImageBitmap(new Blob([raw], { type: meta.mime || "image/jpeg" }));
      frames.push({ bitmap, delay: Math.max(16, Number(frame.delay) || 100) });
    }
    if (!frames.length) throw new Error("动图没有可播放的帧");
    return frames;
  })();
  task.catch(() => {
    if (ugoiraPreviewCache.get(artworkId) === task) ugoiraPreviewCache.delete(artworkId);
  });
  ugoiraPreviewCache.set(artworkId, task);
  while (ugoiraPreviewCache.size > UGOIRA_PREVIEW_CACHE_LIMIT) {
    const oldestKey = ugoiraPreviewCache.keys().next().value;
    const evicted = ugoiraPreviewCache.get(oldestKey);
    ugoiraPreviewCache.delete(oldestKey);
    Promise.resolve(evicted).then((frames) => {
      frames?.forEach((frame) => frame.bitmap?.close());
    }).catch(() => {});
  }
  return task;
}

function stopUgoiraPreview() {
  const player = ugoiraPlayer;
  if (!player) return;
  player.stopped = true;
  clearTimeout(player.timer);
  player.canvas?.remove();
  if (ugoiraPlayer === player) ugoiraPlayer = null;
}

function startUgoiraPreview(host, artworkId) {
  stopUgoiraPreview();
  const player = { canvas: null, frames: null, index: 0, stopped: false, timer: 0 };
  ugoiraPlayer = player;
  loadUgoiraFrames(artworkId).then((frames) => {
    if (player.stopped || ugoiraPlayer !== player) return;
    player.frames = frames;
    // Attach the canvas only once frames are decoded, so the static thumbnail
    // stays visible during loading instead of flashing a dark panel.
    const canvas = document.createElement("canvas");
    canvas.className = "ugoira-preview";
    player.canvas = canvas;
    host.appendChild(canvas);
    const ratio = Math.max(1, window.devicePixelRatio || 1);
    canvas.width = Math.max(1, Math.round(host.clientWidth * ratio));
    canvas.height = Math.max(1, Math.round(host.clientHeight * ratio));
    const context = canvas.getContext("2d");
    const draw = () => {
      if (player.stopped || ugoiraPlayer !== player) return;
      const frame = frames[player.index % frames.length];
      const bitmap = frame.bitmap;
      // Cover-fit: scale to fill the card while keeping the frame aspect ratio.
      const scale = Math.max(canvas.width / bitmap.width, canvas.height / bitmap.height);
      const drawWidth = bitmap.width * scale;
      const drawHeight = bitmap.height * scale;
      context.drawImage(bitmap, (canvas.width - drawWidth) / 2, (canvas.height - drawHeight) / 2, drawWidth, drawHeight);
      player.timer = setTimeout(() => { player.index = (player.index + 1) % frames.length; draw(); }, frame.delay);
    };
    draw();
  }).catch((error) => {
    if (!player.stopped) announceToast(error.message || "动图预览加载失败");
  });
}

function attachUgoiraHoverTargets(root) {
  root.querySelectorAll("[data-ugoira-preview]").forEach((host) => {
    if (host.dataset.ugoiraHoverReady === "1") return;
    host.dataset.ugoiraHoverReady = "1";
    host.addEventListener("mouseenter", () => startUgoiraPreview(host, host.dataset.ugoiraPreview));
    host.addEventListener("mouseleave", stopUgoiraPreview);
  });
}

function syncSearchScopedControls() {
  const resultActionsDisabled = basketSelectionLocked || searchPending || !resultSelectionEnabled || items.length === 0;
  $("#selectAllPage").disabled = resultActionsDisabled;
  $("#clearPageSelection").disabled = resultActionsDisabled;
  const selectionActionsDisabled = basketSelectionLocked || searchPending;
  $("#clearSelection").disabled = selectionActionsDisabled || selectedArtworkIds.size === 0;
  $("#openBatch").disabled = selectionActionsDisabled || selectedArtworkIds.size === 0;
  $("#batchDownload").disabled = basketSelectionLocked || searchPending || singleDownloadPending || selectedPageCount() === 0;
  searchButton.disabled = basketSelectionLocked || searchPending || singleDownloadPending;
  const detailReady = Boolean(
    currentDetailItem
    && activeArtworkId !== null
    && String(currentDetailItem.id) === String(activeArtworkId),
  );
  $("#download").disabled = basketSelectionLocked || searchPending || singleDownloadPending || !detailReady;
}

function clearDetail(message = "选择一件作品查看详情") {
  closeBasketPage();
  document.body.classList.remove("batch-mode");
  lockedDeckPage = null;
  activeArtworkId = null;
  currentDetailItem = null;
  currentDetailContext = null;
  $("#dTitle").textContent = message;
  $("#dWorkType").hidden = true;
  $("#dDesc").textContent = "";
  $("#dArtist").textContent = "—";
  $("#dSize").textContent = "—";
  $("#dBookmarks").textContent = "—";
  $("#dDate").textContent = "—";
  $("#dTags").innerHTML = "";
  $("#deck").innerHTML = "";
  $("#collectionPages").innerHTML = "";
  $("#collectionPageMore").hidden = true;
  $("#deckHint").textContent = "点击搜索结果后加载作品详情";
  $("#quality").innerHTML = "";
  $("#format").innerHTML = "";
  $("#qualityText").textContent = "";
  $("#formatText").textContent = "";
  $("#formatHint").textContent = "";
  $("#viewAll").hidden = true;
  $("#download").disabled = true;
  syncSearchScopedControls();
}

function discardRestrictedSelections() {
  const restrictedIds = new Set();
  const rememberRestricted = (item) => {
    if (item?.restriction === "r18" && item.id !== undefined) restrictedIds.add(item.id);
  };
  items.forEach(rememberRestricted);
  batchCandidateItems.forEach(rememberRestricted);
  selectedArtworks.forEach(rememberRestricted);
  rememberRestricted(currentDetailItem);
  restrictedIds.forEach((id) => {
    selectedArtworkIds.delete(id);
    selectedArtworks.delete(id);
    selectedPagesByArtwork.delete(id);
    selectedContextByArtwork.delete(id);
    selectedResultPageByArtwork.delete(id);
    staleBasketPreviewIds.delete(id);
    archivedArtworkIds.delete(id);
  });
  batchCandidateItems = [];
  batchCandidateContextByArtwork.clear();
  batchCandidateResultPageByArtwork.clear();
  staleBasketPreviewIds.clear();
}

function handleAuthorizationLoss() {
  viewGeneration += 1;
  abortDetailRefreshes();
  cancelActiveSearch();
  if (detailController) detailController.abort();
  searchController = null;
  activeSearchRequestId = null;
  detailController = null;
  searchPending = false;
  resultSelectionEnabled = false;
  $("#safety").value = "safe";
  activeSearchFilters = { ...activeSearchFilters, mode: "safe" };
  closeAllViewer();
  discardRestrictedSelections();
  items = [];
  currentPage = 1;
  pageNumbers = [1];
  firstAvailablePage = 1;
  preloadedThrough = 1;
  searchHasMore = false;
  $("#pagination").innerHTML = "";
  $("#count").textContent = "Pixiv 已断开，请重新搜索";
  $("#tagTitle").textContent = "等待搜索";
  grid.innerHTML = '<div class="empty-state"><b>Pixiv 已断开</b><p>受限预览已清理，请重新搜索。</p></div>';
  clearDetail("Pixiv 已断开，请重新搜索");
  updateSelectionBar();
  searchButton.disabled = basketSelectionLocked;
  searchButton.innerHTML = "开始寻找 <span>↗</span>";
  cancelSearchButton.disabled = false;
  cancelSearchButton.hidden = true;
  syncSearchScopedControls();
}

function updateSelectionBar() {
  const count = selectedArtworkIds.size;
  const pages = selectedPageCount();
  $("#selectionBar").hidden = items.length === 0 && count === 0;
  $("#selectionCount").textContent = count
    ? `采集篮 ${count} 个作品 · ${pages}/${MAX_SELECTED_PAGES} 张图片${archivedArtworkIds.size ? ` · 已归档 ${archivedArtworkIds.size}` : ""}`
    : `当前页 ${items.length} 个作品`;
  $("#clearSelection").disabled = count === 0;
  if (document.body.classList.contains("batch-mode")) updateBatchDetailSummary();
  renderCacheStatus();
  updateFloatingChrome();
  syncSearchScopedControls();
}

function selectedPageCount() {
  return [...selectedPagesByArtwork.values()].reduce((total, pages) => total + pages.size, 0);
}

function selectionWouldExceedPageLimit(additionalPages) {
  const count = Number(additionalPages);
  if (!Number.isSafeInteger(count) || count < 0) return true;
  return selectedPageCount() + count > MAX_SELECTED_PAGES;
}

function validatedArtworkPageCount(item) {
  const count = Number(item?.pages);
  return Number.isSafeInteger(count) && count > 0 ? count : null;
}

function showSelectionLimitDialog(attemptedPages = 1) {
  const remaining = Math.max(0, MAX_SELECTED_PAGES - selectedPageCount());
  $("#selectionLimitText").textContent = `采集篮最多保存 ${MAX_SELECTED_PAGES} 张图片的下载选择。当前还可加入 ${remaining} 张，本次尝试新增 ${attemptedPages} 张。请先取消部分图片。`;
  const dialog = $("#selectionLimitDialog");
  if (dialog?.showModal && !dialog.open) dialog.showModal();
}

function renderCacheStatus() {
  const status = $("#cacheStatus");
  if (!status) return;
  const retainedStart = Math.max(firstAvailablePage, currentPage - SEARCH_KEEP_BEHIND);
  status.textContent = `搜索缓存：当前第 ${currentPage} 页，数据预加载至第 ${preloadedThrough} 页，保留第 ${retainedStart}–${currentPage} 页；缩略图仅加载当前打开页。采集篮缓存：${selectedArtworkIds.size} 个作品、${selectedPageCount()}/${MAX_SELECTED_PAGES} 张已选；只保留元数据和下载链接，不缓存图片二进制。`;
}

function unarchivedSelectionIds() {
  return new Set([...selectedArtworkIds].filter((id) => !archivedArtworkIds.has(id)));
}

function detachSelection(ids) {
  if (basketSelectionLocked) return 0;
  ids.forEach((id) => archivedArtworkIds.add(id));
  updateSelectionBar();
  return ids.size;
}

function clearSelection(ids) {
  if (basketSelectionLocked) return 0;
  ids.forEach((id) => {
    selectedArtworkIds.delete(id);
    selectedArtworks.delete(id);
    selectedPagesByArtwork.delete(id);
    selectedContextByArtwork.delete(id);
    selectedResultPageByArtwork.delete(id);
  });
  updateSelectionBar();
  return ids.size;
}

function clearAllSelection() {
  if (basketSelectionLocked) return false;
  selectedArtworkIds.clear();
  selectedArtworks.clear();
  selectedPagesByArtwork.clear();
  selectedContextByArtwork.clear();
  selectedResultPageByArtwork.clear();
  archivedArtworkIds.clear();
  batchCandidateItems = [];
  batchCandidateContextByArtwork.clear();
  batchCandidateResultPageByArtwork.clear();
  updateSelectionBar();
  return true;
}

function toggleArtworkSelection(item, checked) {
  if (basketSelectionLocked) {
    announceToast("下载任务进行中，本次任务已锁定当前勾选。");
    return false;
  }
  if (checked) {
    const pageCount = validatedArtworkPageCount(item);
    if (pageCount === null) {
      announceToast("作品页数异常，已阻止加入采集篮");
      return false;
    }
    const existingPages = selectedPagesByArtwork.get(item.id);
    const additionalPages = existingPages ? 0 : pageCount;
    if (selectionWouldExceedPageLimit(additionalPages)) {
      showSelectionLimitDialog(additionalPages);
      return false;
    }
    selectedArtworkIds.add(item.id);
    selectedArtworks.set(item.id, item);
    selectedContextByArtwork.set(item.id, { ...activeSearchContext });
    selectedResultPageByArtwork.set(item.id, currentPage);
    if (!selectedPagesByArtwork.has(item.id)) {
      selectedPagesByArtwork.set(item.id, new Set(Array.from({ length: pageCount }, (_, page) => page)));
    }
  } else {
    selectedArtworkIds.delete(item.id);
    selectedArtworks.delete(item.id);
    selectedPagesByArtwork.delete(item.id);
    selectedContextByArtwork.delete(item.id);
    selectedResultPageByArtwork.delete(item.id);
    archivedArtworkIds.delete(item.id);
  }
  updateSelectionBar();
  return true;
}

function selectAllCurrentPage() {
  if (basketSelectionLocked || searchPending || !resultSelectionEnabled) return false;
  let additionalPages = 0;
  const selectionPlan = [];
  for (const item of items) {
    const pageCount = validatedArtworkPageCount(item);
    if (pageCount === null) {
      $("#pageSelectionStatus").textContent = "无法全选：搜索结果包含异常页数";
      return false;
    }
    const existingPages = selectedPagesByArtwork.get(item.id);
    let existingPageCount = 0;
    existingPages?.forEach((page) => {
      if (Number.isInteger(page) && page >= 0 && page < pageCount) existingPageCount += 1;
    });
    additionalPages += Math.max(0, pageCount - existingPageCount);
    selectionPlan.push({ item, pageCount });
    if (selectionWouldExceedPageLimit(additionalPages)) break;
  }
  const status = $("#pageSelectionStatus");
  if (selectionWouldExceedPageLimit(additionalPages)) {
    status.textContent = `无法全选：采集篮最多 ${MAX_SELECTED_PAGES} 张图片`;
    showSelectionLimitDialog(additionalPages);
    return false;
  }
  for (const { item, pageCount } of selectionPlan) {
    const pages = new Set();
    for (let page = 0; page < pageCount; page += 1) pages.add(page);
    selectedArtworkIds.add(item.id);
    selectedArtworks.set(item.id, item);
    selectedPagesByArtwork.set(item.id, pages);
    if (!selectedContextByArtwork.has(item.id)) {
      selectedContextByArtwork.set(item.id, { ...activeSearchContext });
    }
    if (!selectedResultPageByArtwork.has(item.id)) {
      selectedResultPageByArtwork.set(item.id, currentPage);
    }
  }
  updateSelectionBar();
  status.textContent = `已全选当前页 ${items.length} 个作品及其全部图片`;
  render();
  return true;
}

function clearAllCurrentPage() {
  if (basketSelectionLocked || searchPending || !resultSelectionEnabled) return;
  for (const item of items) toggleArtworkSelection(item, false);
  $("#pageSelectionStatus").textContent = "已取消当前页全部选择";
  render();
}

async function search(tag, page = 1, filters = readSearchFilters()) {
  if (basketSelectionLocked || singleDownloadPending) return;
  const previousView = searchController?._mokuRestoreView || {
    count: $("#count").textContent,
    hadCommittedResults: resultSelectionEnabled,
  };
  cancelActiveSearch();
  viewGeneration += 1;
  abortDetailRefreshes();
  if (detailController) detailController.abort();
  searchController = new AbortController();
  const controller = searchController;
  controller._mokuRestoreView = previousView;
  const requestId = nextSearchRequestId();
  activeSearchRequestId = requestId;
  const cleanTag = String(tag || "").trim() || "原创";
  const requestedFilters = {
    mode: filters?.mode || "safe",
    workType: filters?.workType || "all",
    includeAi: Boolean(filters?.includeAi),
    fuzzy: Boolean(filters?.fuzzy),
  };
  const contextMatch = cleanTag.match(/^\s*(pid|uid|author)\s*[:：]\s*(.+)$/i);
  const requestedContext = contextMatch
    ? { kind: contextMatch[1].toLowerCase(), value: contextMatch[2].trim() }
    : { kind: "tags", value: cleanTag };

  searchPending = true;
  resultSelectionEnabled = false;
  searchButton.disabled = true;
  searchButton.textContent = "正在寻找…";
  cancelSearchButton.hidden = false;
  cancelSearchButton.disabled = false;
  $("#download").disabled = true;
  syncSearchScopedControls();
  grid.innerHTML = '<p class="loading-state">正在连接 Pixiv，可随时继续操作页面…</p>';
  $("#pagination").innerHTML = "";
  $("#count").textContent = "正在加载当前页";

  try {
    const query = new URLSearchParams({
      tag: cleanTag,
      page: String(page),
      mode: requestedFilters.mode,
      workType: requestedFilters.workType,
      includeAi: String(requestedFilters.includeAi),
      fuzzy: String(requestedFilters.fuzzy),
      requestId,
    });
    const data = await fetchJson(`/api/pixiv/search?${query}`, { signal: controller.signal }, 90000);
    if (controller !== searchController) return;

    activeTagQuery = cleanTag;
    activeSearchContext = requestedContext;
    activeSearchFilters = requestedFilters;
    items = Array.isArray(data.items) ? data.items : [];
    reconcileSelectedArtworkPreviews(items);
    currentPage = Number(data.page) || 1;
    pageNumbers = Array.isArray(data.availablePages) ? data.availablePages : (Array.isArray(data.pageNumbers) ? data.pageNumbers : [currentPage]);
    firstAvailablePage = pageNumbers.length ? Number(pageNumbers[0]) : currentPage;
    preloadedThrough = Number(data.preloadedThrough) || currentPage;
    searchHasMore = Boolean(data.hasMore);
    $("#tagTitle").textContent = data.label || (Array.isArray(data.tags) && data.tags.length ? data.tags.join(" + ") : (data.tag || cleanTag));
    const preloadStatus = data.preloadedThrough > currentPage ? ` · 已预加载至第 ${data.preloadedThrough} 页` : "";
    const historyStatus = data.budgetExhausted ? " · 本次加载达到请求预算，可继续翻页" : (data.hasMore ? " · 可继续加载更早作品" : " · 已到历史末尾");
    const fuzzyLabel = data.fuzzy ? " · 别名扩展已启用" : "";
    $("#count").textContent = `已加载 ${data.total} 件 · 第 ${currentPage} 页 · 每页 ${data.perPage || 36} 件${fuzzyLabel}${preloadStatus}${historyStatus}${data.truncatedDates?.length ? ` · ${data.truncatedDates.length} 个高密度日期受平台截断` : ""}`;
    resultSelectionEnabled = true;
    render();
    renderPagination();
    clearDetail();
  } catch (error) {
    if (controller.signal.aborted) {
      if (controller === searchController) {
        resultSelectionEnabled = previousView.hadCommittedResults;
        if (previousView.hadCommittedResults) {
          render();
          renderPagination();
          $("#count").textContent = previousView.count;
        } else {
          grid.innerHTML = '<div class="empty-state"><b>搜索已取消</b><p>调整条件后可以重新开始寻找。</p></div>';
          $("#pagination").innerHTML = "";
          $("#count").textContent = "搜索已取消";
        }
      }
      return;
    }
    grid.innerHTML = `<div class="error-state"><b>加载失败</b><p>${esc(error.message || "Pixiv 搜索失败")}</p><button id="retrySearch" type="button">重试当前搜索</button></div>`;
    $("#count").textContent = "连接未完成";
    $("#retrySearch")?.addEventListener("click", () => search(cleanTag, page, requestedFilters));
  } finally {
    if (controller === searchController) {
      searchController = null;
      activeSearchRequestId = null;
      searchPending = false;
      searchButton.disabled = false;
      searchButton.innerHTML = "开始寻找 <span>↗</span>";
      cancelSearchButton.disabled = false;
      cancelSearchButton.hidden = true;
      syncSearchScopedControls();
    }
  }
}

function syncResultSelectionControls() {
  grid.querySelectorAll("[data-select]").forEach((box) => {
    const item = items[Number(box.dataset.select)];
    box.checked = Boolean(item && selectedArtworkIds.has(item.id));
  });
}

function reconcileSelectedArtworkPreviews(freshItems) {
  const freshById = new Map(freshItems.map((item) => [String(item.id), item]));
  const mergePreview = (existing) => {
    const fresh = freshById.get(String(existing.id));
    if (!fresh) return existing;
    const merged = { ...existing, ...fresh };
    if (Array.isArray(existing.pageImages) && existing.pageImages.length) {
      merged.pageImages = existing.pageImages;
      merged.thumb = fresh.thumb || existing.thumb;
    }
    return merged;
  };
  selectedArtworks.forEach((item, artworkId) => {
    const merged = mergePreview(item);
    if (merged !== item) selectedArtworks.set(artworkId, merged);
  });
  batchCandidateItems = batchCandidateItems.map(mergePreview);
}

function render() {
  gallery.classList.add("in");
  grid.className = "grid";
  updateSelectionBar();
  syncSearchScopedControls();
  if (!items.length) {
    grid.innerHTML = '<p class="empty-state">当前页没有符合安全范围的作品。</p>';
    return;
  }

  grid.innerHTML = items.map((item, index) => {
    const image = `<img src="${item.thumb}" alt="${esc(item.title)}" loading="lazy" decoding="async">`;
    const checked = selectedArtworkIds.has(item.id) ? "checked" : "";
    const badges = `${item.workType === "ugoira" ? '<span class="series type-ugoira">动图</span>' : ""}${item.pages > 1 ? `<span class="series">叠图 ${item.pages}P</span>` : ""}`;
    const ugoiraHover = item.workType === "ugoira" ? ` data-ugoira-preview="${esc(String(item.id))}"` : "";
    return `<article class="card" tabindex="0" data-i="${index}"><label class="card-select"><input type="checkbox" data-select="${index}" ${checked}><span>选择</span></label><div class="poster"${ugoiraHover}>${image}${badges}</div><div class="meta"><div><h3>${esc(item.title)}</h3><p>${esc(item.artist)} · ${item.tags.map((tag) => `#${esc(tag)}`).join(" ")}</p></div><span>♡ ${Number(item.bookmarks || 0).toLocaleString()}</span></div></article>`;
  }).join("");
  installImageFallbacks(grid);
  attachUgoiraHoverTargets(grid);

  grid.querySelectorAll("[data-i]").forEach((card) => {
    const open = () => {
      select(Number(card.dataset.i));
      $("#detail").scrollIntoView({ behavior: "auto" });
    };
    card.onclick = (event) => { if (!event.target.closest(".card-select")) open(); };
    card.onkeydown = (event) => {
      if (event.target.closest(".card-select")) return;
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        open();
      }
    };
  });
  grid.querySelectorAll("[data-select]").forEach((box) => {
    box.onchange = () => {
      const accepted = toggleArtworkSelection(items[Number(box.dataset.select)], box.checked);
      if (!accepted) box.checked = false;
    };
  });
}

function renderPagination() {
  const pagination = $("#pagination");
  const canLoadNext = currentPage < preloadedThrough || searchHasMore;
  pagination.innerHTML = `<button ${currentPage <= firstAvailablePage ? "disabled" : ""} data-page="${currentPage - 1}" aria-label="上一页">←</button>${pageNumbers.map((number) => number === null ? '<span class="page-gap">…</span>' : `<button class="${number === currentPage ? "active" : ""}" data-page="${number}">${number}</button>`).join("")}<button ${canLoadNext ? "" : "disabled"} data-page="${currentPage + 1}" aria-label="${currentPage < preloadedThrough ? "下一页" : "继续加载下一页"}">→</button>`;
  pagination.querySelectorAll("button:not([disabled])").forEach((button) => {
    button.onclick = () => {
      navigateToPage(Number(button.dataset.page));
    };
  });
  updatePaginationDock();
  updateFloatingChrome();
}

function updatePaginationDock() {
  const dock = document.querySelector(".pagination-dock");
  const hasPagination = Boolean($("#pagination").children.length);
  const overlayOpen = !$("#allViewer").hidden || basketPageOpen();
  const galleryRect = $("#gallery").getBoundingClientRect();
  const dockTop = window.innerHeight - (dock.offsetHeight || 0);
  const dockOverGallery = galleryRect.top < dockTop && galleryRect.bottom > dockTop;
  dock.classList.toggle("is-visible", hasPagination && !overlayOpen && dockOverGallery);
}

function activeScrollSurface() {
  if (!$("#allViewer").hidden) return $("#allViewer");
  if (basketPageOpen()) return $("#basketPage");
  return window;
}

function updateFloatingChrome() {
  const surface = activeScrollSurface();
  const overlayOpen = surface !== window;
  const scrollOffset = surface === window ? window.scrollY : surface.scrollTop;
  $("#backTop").classList.toggle("is-visible", scrollOffset > 600);
  const entry = $("#basketEntry");
  const count = selectedArtworkIds.size;
  entry.classList.toggle("is-visible", !overlayOpen && count > 0);
  entry.textContent = `采集篮 ${count} 作品 · ${selectedPageCount()} 张`;
  entry.disabled = basketSelectionLocked || searchPending;
}

function schedulePaginationDockUpdate() {
  if (paginationDockFrame !== null) return;
  const run = () => {
    paginationDockFrame = null;
    updatePaginationDock();
    updateFloatingChrome();
  };
  paginationDockFrame = 1;
  if (typeof requestAnimationFrame === "function") requestAnimationFrame(run);
  else setTimeout(run, 16);
}

window.addEventListener("scroll", schedulePaginationDockUpdate, { passive: true });
window.addEventListener("resize", schedulePaginationDockUpdate, { passive: true });
$("#basketPage").addEventListener("scroll", schedulePaginationDockUpdate, { passive: true });
$("#allViewer").addEventListener("scroll", schedulePaginationDockUpdate, { passive: true });

async function select(index) {
  let item = items[index];
  if (!item) return;
  closeBasketPage();
  document.body.classList.remove("batch-mode");
  if (detailController) detailController.abort();
  viewGeneration += 1;
  abortDetailRefreshes();
  detailController = new AbortController();
  const controller = detailController;
  const generation = viewGeneration;
  const detailContext = { ...activeSearchContext };
  activeArtworkId = item.id;

  announceToast("");
  $("#dTitle").textContent = "正在加载作品详情…";
  $("#deck").innerHTML = '<p class="loading-state">正在读取作品信息</p>';
  $("#download").disabled = true;

  try {
    if (item.source === "pixiv" && !item.pageImages) {
      item = await fetchJson(`/api/pixiv/artwork/${item.id}`, { signal: controller.signal }, 18000);
      if (controller !== detailController || generation !== viewGeneration) return;
      items[index] = item;
      if (selectedArtworkIds.has(item.id)) {
        selectedArtworks.set(item.id, item);
        const candidateIndex = batchCandidateItems.findIndex((candidate) => String(candidate.id) === String(item.id));
        if (candidateIndex >= 0) batchCandidateItems[candidateIndex] = item;
      }
    }
    if (controller !== detailController || generation !== viewGeneration) return;
    renderDetail(item, index, detailContext);
  } catch (error) {
    if (controller.signal.aborted) return;
    $("#dTitle").textContent = "作品详情加载失败";
    $("#deck").innerHTML = "";
    announceToast(error.message || "作品详情加载失败");
  } finally {
    if (controller === detailController) detailController = null;
  }
}

function downloadButtonLabel(item) {
  return item?.workType === "ugoira" ? "下载动图 ZIP ↓" : "下载本作品 ↓";
}

function renderDetail(item, index, detailContext = activeSearchContext) {
  lockedDeckPage = null;
  currentDetailItem = item;
  currentDetailContext = { ...detailContext };
  collectionPageOffset = 0;
  $("#dTitle").textContent = item.title;
  $("#dWorkType").hidden = item.workType !== "ugoira";
  $("#dDesc").textContent = item.description;
  $("#dArtist").textContent = item.artist;
  $("#dSize").textContent = `${item.width} × ${item.height} px`;
  $("#dBookmarks").textContent = Number(item.bookmarks || 0).toLocaleString();
  $("#dDate").textContent = item.date;
  $("#dTags").innerHTML = item.tags.map((tag) => `<span>#${esc(tag)}</span>`).join("");
  renderCollectionPageWindow(item);

  const visible = Math.min(item.pages, 4);
  const middle = (visible - 1) / 2;
  $("#deck").innerHTML = Array.from({ length: visible }, (_, page) => {
    const delta = page - middle;
    const angle = delta * 3.2;
    const lift = Math.abs(delta) * 4;
    const fallback = `/api/image/${(currentPage - 1) * 12 + index}/${page}?size=preview`;
    const src = item.pageImages?.[page]?.regular || item.thumb || fallback;
    return `<button class="deck-card" data-page="${page}" style="--i:${page};--angle:${angle}deg;--lift:${lift}px" aria-label="第 ${page + 1} 张" aria-pressed="false"><img src="${esc(src)}" data-detail-artwork="${esc(item.id)}" data-detail-page="${page}" alt="${esc(item.title)} 第 ${page + 1} 张" loading="lazy" decoding="async"><span>${page + 1} / ${item.pages}</span></button>`;
  }).join("");
  installImageFallbacks($("#deck"));

  $("#deck").querySelectorAll(".deck-card").forEach((card) => {
    card.onmouseenter = () => previewDeckCard(card);
    card.onmouseleave = () => { if (lockedDeckPage === null) resetDeckFan(); };
    card.onclick = () => toggleDeckCard(card);
  });
  $("#viewAll").hidden = item.pages <= visible;
  $("#deckHint").textContent = item.pages > visible ? `预览前 ${visible} 张，共 ${item.pages} 张；点击一张固定，再点一次取消` : "轻移鼠标预览；点击一张固定，再点一次取消";
  $("#quality").innerHTML = item.qualities.map((quality) => `<option value="${quality.id}">${esc(quality.label)} · ${quality.width} × ${quality.height}</option>`).join("");
  $("#format").innerHTML = item.formats.map((format) => `<option value="${format.id}">${esc(format.label)}</option>`).join("");
  $("#download").textContent = downloadButtonLabel(item);
  syncSearchScopedControls();
  updateFormatHint();
}

function syncBasketArtworkMeta() {
  if (!basketDetailItem) return;
  const selectedPages = selectedPagesByArtwork.get(basketDetailItem.id);
  $("#batchSummary").textContent = `已选 ${selectedPages?.size || 0}/${basketDetailItem.pages} 张`;
  $("#basketModeHint").textContent = `${basketDetailItem.artist} · 在作品详情中逐张勾选`;
}

function bindCollectionPageInputs(pagesRoot, item) {
  pagesRoot.querySelectorAll("[data-collection-page]").forEach((box) => {
    box.onchange = () => {
      if (basketSelectionLocked) {
        box.checked = Boolean(selectedPagesByArtwork.get(item.id)?.has(Number(box.dataset.collectionPage)));
        return;
      }
      let set = selectedPagesByArtwork.get(item.id);
      const page = Number(box.dataset.collectionPage);
      if (box.checked) {
        if (!set) {
          set = new Set();
          selectedPagesByArtwork.set(item.id, set);
        }
        if (!set.has(page) && selectionWouldExceedPageLimit(1)) {
          box.checked = false;
          if (!set.size) selectedPagesByArtwork.delete(item.id);
          showSelectionLimitDialog(1);
          return;
        }
        set.add(page);
      } else if (set) {
        set.delete(page);
      }
      if (set?.size) {
        selectedArtworks.set(item.id, item);
        selectedArtworkIds.add(item.id);
        if (!selectedResultPageByArtwork.has(item.id)) {
          selectedResultPageByArtwork.set(item.id, batchCandidateResultPageByArtwork.get(item.id) || currentPage);
        }
        if (!selectedContextByArtwork.has(item.id)) {
          selectedContextByArtwork.set(item.id, batchCandidateContextByArtwork.get(item.id) || { ...activeSearchContext });
        }
      } else {
        selectedPagesByArtwork.delete(item.id);
        selectedArtworks.delete(item.id);
        selectedArtworkIds.delete(item.id);
        selectedContextByArtwork.delete(item.id);
        selectedResultPageByArtwork.delete(item.id);
        archivedArtworkIds.delete(item.id);
      }
      updateSelectionBar();
      syncResultSelectionControls();
      if (basketPageOpen()) {
        syncBasketHeader();
        syncBasketArtworkMeta();
      }
    };
  });
}

function renderCollectionWindowInto(item, pagesRoot, moreButton) {
  const pages = item.pageImages || [];
  const chosenPages = selectedPagesByArtwork.get(item.id);
  const start = collectionPageOffset;
  const end = Math.min(pages.length, start + DETAIL_PAGE_WINDOW);
  const ugoiraHover = item.workType === "ugoira" ? ` data-ugoira-preview="${esc(String(item.id))}"` : "";
  pagesRoot.innerHTML = pages.slice(start, end).map((page, localIndex) => {
    const pageNo = start + localIndex;
    return `<label class="page-select"${ugoiraHover}><input type="checkbox" data-collection-page="${pageNo}" ${chosenPages?.has(pageNo) ? "checked" : ""} ${basketSelectionLocked ? "disabled" : ""}><img src="${esc(page.regular)}" data-detail-artwork="${esc(item.id)}" data-detail-page="${pageNo}" alt="${esc(item.title)} 第 ${pageNo + 1} 张" loading="lazy" decoding="async"><span>${pageNo + 1}</span></label>`;
  }).join("");
  installImageFallbacks(pagesRoot);
  attachUgoiraHoverTargets(pagesRoot);
  bindCollectionPageInputs(pagesRoot, item);
  moreButton.hidden = pages.length <= DETAIL_PAGE_WINDOW;
  moreButton.textContent = `${start + 1}–${Math.max(start + 1, end)} / ${pages.length} · 显示后 ${DETAIL_PAGE_WINDOW} 张`;
}

function renderCollectionPageWindow(item = currentDetailItem) {
  if (!item) return;
  renderCollectionWindowInto(item, $("#collectionPages"), $("#collectionPageMore"));
}

function previewDeckCard(card) {
  if (lockedDeckPage !== null) return;
  resetDeckFan();
  card.classList.add("deck-preview");
}

function toggleDeckCard(card) {
  const page = Number(card.dataset.page);
  if (lockedDeckPage !== null && lockedDeckPage !== page) return;
  if (lockedDeckPage === page) {
    lockedDeckPage = null;
    resetDeckFan();
    $("#deckHint").textContent = "已取消固定；轻移鼠标预览，点击一张可再次固定";
    return;
  }
  lockedDeckPage = page;
  const cards = [...$("#deck").querySelectorAll(".deck-card")];
  cards.forEach((row) => {
    const selected = Number(row.dataset.page) === page;
    row.classList.toggle("deck-locked", selected);
    row.classList.toggle("deck-inert", !selected);
    row.setAttribute("aria-pressed", String(selected));
  });
  $("#deckHint").textContent = `已固定第 ${page + 1} 张；其他牌保持不动，再点当前牌取消`;
}

function resetDeckFan() {
  $("#deck").querySelectorAll(".deck-card").forEach((card) => {
    card.classList.remove("deck-preview", "deck-locked", "deck-inert");
    card.setAttribute("aria-pressed", "false");
  });
}

function renderViewerWindow(item) {
  const pages = Array.isArray(item?.pageImages) ? item.pageImages : [];
  const lastStart = Math.max(0, Math.floor(Math.max(0, pages.length - 1) / VIEWER_PAGE_WINDOW) * VIEWER_PAGE_WINDOW);
  const start = Math.min(Math.max(0, viewerPageOffset), lastStart);
  const end = Math.min(pages.length, start + VIEWER_PAGE_WINDOW);
  viewerPageOffset = start;
  const navigation = pages.length > VIEWER_PAGE_WINDOW
    ? `<div class="pagination viewer-window-pagination" style="grid-column:1/-1" aria-label="连续查看分页"><button type="button" data-viewer-window="${Math.max(0, start - VIEWER_PAGE_WINDOW)}" ${start === 0 ? "disabled" : ""}>← 前 ${VIEWER_PAGE_WINDOW} 张</button><span>${start + 1}–${end} / ${pages.length}</span><button type="button" data-viewer-window="${Math.min(lastStart, start + VIEWER_PAGE_WINDOW)}" ${end >= pages.length ? "disabled" : ""}>后 ${VIEWER_PAGE_WINDOW} 张 →</button></div>`
    : "";
  $("#viewerGrid").innerHTML = `${navigation}${item.pageImages.slice(start, end).map((page, localIndex) => {
    const pageNo = start + localIndex;
    return `<figure><img src="${esc(page.regular)}" data-detail-artwork="${esc(item.id)}" data-detail-page="${pageNo}" alt="${esc(item.title)} 第 ${pageNo + 1} 张" loading="lazy" decoding="async"><span>${String(pageNo + 1).padStart(2, "0")} / ${String(pages.length).padStart(2, "0")}</span></figure>`;
  }).join("")}`;
  installImageFallbacks($("#viewerGrid"));
  $("#viewerGrid").querySelectorAll("[data-viewer-window]:not([disabled])").forEach((button) => {
    button.onclick = () => {
      viewerPageOffset = Number(button.dataset.viewerWindow) || 0;
      const latestItem = String(currentDetailItem?.id || "") === String(item.id)
        ? currentDetailItem
        : selectedArtworks.get(item.id) || items.find((row) => String(row.id) === String(item.id)) || item;
      renderViewerWindow(latestItem);
      $("#allViewer").scrollTop = 0;
    };
  });
  $("#viewerCount").textContent = pages.length > VIEWER_PAGE_WINDOW
    ? `${pages.length} 张 · 当前 ${start + 1}–${end}`
    : `${pages.length} 张 · 连续浏览`;
}

function openAllViewer() {
  const activeDetail = currentDetailItem
    && activeArtworkId !== null
    && String(currentDetailItem.id) === String(activeArtworkId)
    ? currentDetailItem
    : null;
  const item = activeDetail || selectedArtworks.get(activeArtworkId) || items.find((row) => row.id === activeArtworkId);
  if (!item?.pageImages) return;
  viewerPageOffset = 0;
  $("#viewerTitle").textContent = item.title;
  $("#viewerArtist").textContent = item.artist;
  renderViewerWindow(item);
  $("#allViewer").hidden = false;
  document.body.classList.add("viewer-open");
  $("#allViewer").scrollTop = 0;
  schedulePaginationDockUpdate();
}

function closeAllViewer() {
  viewerPageOffset = 0;
  $("#allViewer").hidden = true;
  document.body.classList.remove("viewer-open");
  $("#viewerGrid").innerHTML = "";
  $("#viewerTitle").textContent = "";
  $("#viewerArtist").textContent = "";
  $("#viewerCount").textContent = "";
  schedulePaginationDockUpdate();
}

$("#viewAll").onclick = openAllViewer;
$("#closeViewer").onclick = closeAllViewer;
function advanceCollectionWindow(item, rerender) {
  const pageCount = (item?.pageImages || []).length;
  collectionPageOffset = collectionPageOffset + DETAIL_PAGE_WINDOW >= pageCount
    ? 0
    : collectionPageOffset + DETAIL_PAGE_WINDOW;
  rerender();
}

$("#collectionPageMore").onclick = () => advanceCollectionWindow(currentDetailItem, () => renderCollectionPageWindow());
$("#basketPageMore").onclick = () => {
  if (!basketDetailItem) return;
  advanceCollectionWindow(basketDetailItem, () => renderBasketArtworkDetail(basketDetailItem));
};
$("#basketViewAll").onclick = openAllViewer;
$("#backTop").onclick = () => activeScrollSurface().scrollTo({ top: 0, behavior: "smooth" });
function openBatchHub() {
  if (basketSelectionLocked || searchPending) return;
  if (!selectedArtworkIds.size) {
    $("#pageSelectionStatus").textContent = "请先勾选至少一个作品";
    return;
  }
  showBatchDetail();
}
$("#basketEntry").onclick = openBatchHub;

function basketPageOpen() {
  return !$("#basketPage").hidden;
}

function openBasketPage() {
  $("#basketPage").hidden = false;
  document.body.classList.add("basket-page-open");
  updateFloatingChrome();
}

function updateBatchDetailSummary() {
  $("#batchDetailSummary").textContent = `${selectedArtworkIds.size} 个作品 · ${selectedPageCount()}/${MAX_SELECTED_PAGES} 张已选`;
}

function showBatchDetail() {
  closeBasketPage();
  document.body.classList.add("batch-mode");
  ensureDownloadOptionDefaults();
  updateBatchDetailSummary();
  $("#detail").scrollIntoView({ behavior: "auto" });
}

function closeBasketPage() {
  const wasOpen = !$("#basketPage").hidden;
  $("#basketPage").hidden = true;
  document.body.classList.remove("basket-page-open");
  basketReturnMode = "summary";
  basketDetailItem = null;
  basketLockedDeckPage = null;
  stopUgoiraPreview();
  // Restricted previews must not linger in the hidden basket DOM.
  $("#batchCollections").innerHTML = "";
  $("#basketArtworkDetail").hidden = true;
  $("#basketDetailDeck").innerHTML = "";
  $("#basketPages").innerHTML = "";
  $("#basketPageMore").hidden = true;
  $("#basketViewAll").hidden = true;
  if (!wasOpen) return;
  viewGeneration += 1;
  abortDetailRefreshes();
  if (detailController) detailController.abort();
  detailController = null;
  updateFloatingChrome();
}

function showBasketPane(mode) {
  basketReturnMode = mode;
  $("#batchCollections").hidden = mode !== "picker";
  $("#basketArtworkDetail").hidden = mode !== "detail";
}

function ensureDownloadOptionDefaults() {
  if (!$("#quality").options.length) {
    $("#quality").innerHTML = '<option value="regular">预览清晰度</option><option value="original">原图</option>';
  }
  if (!$("#format").options.length) {
    $("#format").innerHTML = '<option value="source">保留源格式</option>';
  }
}

function syncBasketHeader() {
  const chosen = batchCandidateItems;
  if (!chosen.length) {
    $("#batchSummary").textContent = `${selectedPageCount()}/${MAX_SELECTED_PAGES} 张图片已选`;
    return;
  }
  const selectedCount = chosen.filter((item) => selectedPagesByArtwork.get(item.id)?.size).length;
  $("#batchSummary").textContent = `${selectedCount}/${chosen.length} 个作品已勾选 · ${selectedPageCount()}/${MAX_SELECTED_PAGES} 张`;
}

function openSelectionBasket() {
  if (basketSelectionLocked || searchPending) return;
  const chosen = [...selectedArtworks.values()].filter((item) => selectedPagesByArtwork.get(item.id)?.size);
  if (!chosen.length) {
    $("#pageSelectionStatus").textContent = "请先勾选至少一个作品";
    return;
  }
  viewGeneration += 1;
  abortDetailRefreshes();
  if (detailController) detailController.abort();
  detailController = null;
  batchCandidateItems = chosen;
  batchCandidateContextByArtwork.clear();
  batchCandidateResultPageByArtwork.clear();
  for (const item of chosen) {
    batchCandidateContextByArtwork.set(item.id, selectedContextByArtwork.get(item.id) || { ...activeSearchContext });
    batchCandidateResultPageByArtwork.set(item.id, selectedResultPageByArtwork.get(item.id) || currentPage);
  }
  basketArtworkOffset = 0;
  ensureDownloadOptionDefaults();
  openBasketArtworkPicker();
  openBasketPage();
  $("#basketPage").scrollTop = 0;
}

function applyBasketArtworkSelection(item, box) {
  const accepted = toggleArtworkSelection(item, box.checked);
  if (!accepted) {
    box.checked = Boolean(selectedPagesByArtwork.get(item.id)?.size);
    return false;
  }
  if (box.checked) {
    selectedContextByArtwork.set(item.id, batchCandidateContextByArtwork.get(item.id) || { ...activeSearchContext });
    selectedResultPageByArtwork.set(item.id, batchCandidateResultPageByArtwork.get(item.id) || currentPage);
  }

  const selectedPages = selectedPagesByArtwork.get(item.id);
  const selected = Boolean(selectedPages?.size);
  box.checked = selected;
  const card = box.closest(".batch-collection");
  card?.classList.toggle("is-selected", selected);
  const label = card?.querySelector(".batch-card-select");
  label?.setAttribute("aria-label", `${selected ? "取消选择" : "选择"} ${item.title}`);
  const selectionLabel = card?.querySelector(".batch-card-copy small");
  if (selectionLabel) selectionLabel.textContent = `${item.artist} · 已选 ${selectedPages?.size || 0}/${item.pages} 张`;

  const selectedCount = batchCandidateItems.filter((candidate) => selectedPagesByArtwork.get(candidate.id)?.size).length;
  $("#batchSummary").textContent = `${selectedCount}/${batchCandidateItems.length} 个作品已勾选 · ${selectedPageCount()}/${MAX_SELECTED_PAGES} 张`;
  syncResultSelectionControls();
  return true;
}

function openBasketArtworkPicker() {
  const chosen = batchCandidateItems;
  if (!chosen.length) return;
  const lastStart = Math.max(0, Math.floor(Math.max(0, chosen.length - 1) / BASKET_ARTWORK_WINDOW) * BASKET_ARTWORK_WINDOW);
  const start = Math.min(Math.max(0, basketArtworkOffset), lastStart);
  const end = Math.min(chosen.length, start + BASKET_ARTWORK_WINDOW);
  basketArtworkOffset = start;
  ensureDownloadOptionDefaults();
  showBasketPane("picker");
  const selectedCount = chosen.filter((item) => selectedPagesByArtwork.get(item.id)?.size).length;
  $("#basketTitle").textContent = "采集篮 · 选择要下载的作品";
  $("#basketModeHint").textContent = "点击作品进入详情并逐张选择图片；返回回到第三页下载选项。";
  $("#batchSummary").textContent = `${selectedCount}/${chosen.length} 个作品已勾选 · ${selectedPageCount()}/${MAX_SELECTED_PAGES} 张`;
  const navigation = chosen.length > BASKET_ARTWORK_WINDOW
    ? `<div class="pagination basket-window-pagination" style="grid-column:1/-1" aria-label="采集篮作品分页"><button type="button" data-basket-window="${Math.max(0, start - BASKET_ARTWORK_WINDOW)}" ${start === 0 ? "disabled" : ""}>← 前 ${BASKET_ARTWORK_WINDOW} 件</button><span>${start + 1}–${end} / ${chosen.length}</span><button type="button" data-basket-window="${Math.min(lastStart, start + BASKET_ARTWORK_WINDOW)}" ${end >= chosen.length ? "disabled" : ""}>后 ${BASKET_ARTWORK_WINDOW} 件 →</button></div>`
    : "";
  $("#batchCollections").innerHTML = `${navigation}${chosen.slice(start, end).map((item) => {
    const selectedPages = selectedPagesByArtwork.get(item.id);
    const selected = Boolean(selectedPages?.size);
    const selectedPagesLabel = `${selectedPages?.size || 0}/${item.pages} 张`;
    const ugoiraHover = item.workType === "ugoira" ? ` data-ugoira-preview="${esc(String(item.id))}"` : "";
    return `<article class="batch-collection ${selected ? "is-selected" : ""}" data-batch-artwork="${esc(item.id)}"><label class="batch-card-select" aria-label="${selected ? "取消选择" : "选择"} ${esc(item.title)}"><input type="checkbox" data-batch-select="${esc(item.id)}" ${selected ? "checked" : ""}><span aria-hidden="true">✓</span></label><button class="batch-card-open" type="button" data-open-collection="${esc(item.id)}" aria-label="打开 ${esc(item.title)} 的作品详情并选择图片"><span class="batch-card-cover"${ugoiraHover}><img src="${esc(item.thumb)}" data-basket-artwork="${esc(item.id)}" alt="${esc(item.title)}" loading="lazy" decoding="async"><span class="batch-page-count" aria-hidden="true">${item.pages}P</span></span><span class="batch-card-copy"><b>${esc(item.title)}</b><small>${esc(item.artist)} · 已选 ${selectedPagesLabel}</small></span></button></article>`;
  }).join("")}`;
  installImageFallbacks($("#batchCollections"));
  attachUgoiraHoverTargets($("#batchCollections"));
  $("#batchCollections").querySelectorAll("[data-basket-window]:not([disabled])").forEach((button) => {
    button.onclick = () => {
      basketArtworkOffset = Number(button.dataset.basketWindow) || 0;
      openBasketArtworkPicker();
      $("#basketPage").scrollTop = 0;
    };
  });
  $("#batchCollections").querySelectorAll("[data-batch-select]").forEach((box) => {
    box.onchange = () => {
      const item = batchCandidateItems.find((candidate) => candidate.id === box.dataset.batchSelect);
      if (!item) return;
      applyBasketArtworkSelection(item, box);
    };
  });
  $("#batchCollections").querySelectorAll("[data-open-collection]").forEach((button) => {
    button.onclick = () => openBatchCollection(button.dataset.openCollection);
  });
}

function selectedGroups() {
  return [...selectedPagesByArtwork.entries()]
    .map(([id, pages]) => ({
      id,
      pages: [...pages].sort((a, b) => a - b),
      context: selectedContextByArtwork.get(id) || activeSearchContext,
    }))
    .filter((group) => group.pages.length);
}

function contextKey(context) {
  return `${context?.kind || "tags"}\u0000${context?.value || ""}`;
}

function planContextDownloadChunks(groups) {
  const buckets = new Map();
  for (const group of groups) {
    const key = contextKey(group.context);
    if (!buckets.has(key)) buckets.set(key, { context: group.context, groups: [] });
    buckets.get(key).groups.push({ id: group.id, pages: group.pages });
  }
  return [...buckets.values()].flatMap((bucket) =>
    planDownloadChunks(bucket.groups).map((chunk) => ({ ...chunk, context: bucket.context }))
  );
}

function prepareBatchTask(chunks, taskOptions) {
  const signature = JSON.stringify({ chunks, taskOptions });
  if (
    resumableBatchTask?.signature === signature
    && resumableBatchTask.remainingChunks.length
  ) {
    return resumableBatchTask;
  }
  return {
    signature,
    remainingChunks: chunks,
    savedCount: 0,
    completedBatches: 0,
    totalBatches: chunks.length,
  };
}

function setDownloadButtonState(button, text, disabled) {
  button.disabled = disabled;
  button.textContent = text;
}

function setBasketSelectionLocked(locked) {
  basketSelectionLocked = locked;
  const controls = document.querySelectorAll("[data-select],[data-batch-select],[data-collection-page],[data-open-collection],#selectAllPage,#clearPageSelection,#clearSelection,#basketBack,#basketEntry,#openBasketPicker,#searchForm input,#searchSubmit,#searchForm select,#pagination button");
  controls.forEach((control) => {
    if (locked) {
      control.dataset.basketLockDisabled = String(control.disabled);
      control.disabled = true;
    } else {
      control.disabled = control.dataset.basketLockDisabled === "true";
      delete control.dataset.basketLockDisabled;
    }
  });
  if (!locked) {
    $("#clearSelection").disabled = selectedArtworkIds.size === 0;
    $("#basketEntry").disabled = basketSelectionLocked || searchPending;
  }
  updateFloatingChrome();
  syncSearchScopedControls();
}

function downloadPayload(item, sourceIndex) {
  if (item.source === "pixiv") {
    const downloadContext = currentDetailContext || activeSearchContext;
    return {
      endpoint: "/api/pixiv/download",
      body: { id: item.id, quality: $("#quality").value, saveRoot: $("#saveRoot").value.trim(), createFolder: $("#createFolder").checked, context: downloadContext },
      timeout: 120000,
    };
  }
  return {
    endpoint: "/api/download",
    body: { index: (currentPage - 1) * 12 + sourceIndex, pages: item.pages, quality: $("#quality").value, format: $("#format").value, tag: $("#tagTitle").textContent },
    timeout: 120000,
  };
}

function scrollToResults() {
  $("#gallery").scrollIntoView({ behavior: "auto" });
}

function planDownloadChunks(groups) {
  const chunks = [];
  let current = [];
  let pageCount = 0;
  for (const group of groups) {
    for (let offset = 0; offset < group.pages.length; offset += DOWNLOAD_CHUNK_PAGES) {
      const part = { ...group, pages: group.pages.slice(offset, offset + DOWNLOAD_CHUNK_PAGES) };
      if (current.length && (
        pageCount + part.pages.length > DOWNLOAD_CHUNK_PAGES
        || current.length >= DOWNLOAD_CHUNK_ARTWORKS
      )) {
        chunks.push({ groups: current, pageCount });
        current = [];
        pageCount = 0;
      }
      current.push(part);
      pageCount += part.pages.length;
    }
  }
  if (current.length) chunks.push({ groups: current, pageCount });
  return chunks;
}

function openCapacityDialog(targetPage) {
  pendingNavigationPage = targetPage;
  const dialog = $("#capacityDialog");
  if (dialog?.showModal) dialog.showModal();
}

function selectionWouldBeEvicted(targetPage) {
  const oldestRetainedPage = Math.max(1, targetPage - SEARCH_KEEP_BEHIND);
  return [...unarchivedSelectionIds()].some(
    (id) => (selectedResultPageByArtwork.get(id) || currentPage) < oldestRetainedPage,
  );
}

function navigateToPage(page) {
  if (basketSelectionLocked) return;
  if (selectionWouldBeEvicted(page)) {
    openCapacityDialog(page);
    return;
  }
  search(activeTagQuery, page, { ...activeSearchFilters });
  scrollToResults();
}

function archiveAndContinue() {
  const page = pendingNavigationPage;
  pendingNavigationPage = null;
  const detached = detachSelection(unarchivedSelectionIds());
  $("#capacityDialog")?.close();
  if (page !== null) {
    announceToast(`已将当前 ${detached} 个作品放入采集篮；继续翻页不会下载原图`);
    search(activeTagQuery, page, { ...activeSearchFilters });
    scrollToResults();
  }
}

function clearAndContinue() {
  const page = pendingNavigationPage;
  pendingNavigationPage = null;
  clearSelection(unarchivedSelectionIds());
  $("#capacityDialog")?.close();
  if (page !== null) {
    search(activeTagQuery, page, { ...activeSearchFilters });
    scrollToResults();
  }
}

function cancelCapacityDecision() {
  pendingNavigationPage = null;
  $("#capacityDialog")?.close();
}

$("#archiveAndContinue").onclick = archiveAndContinue;
$("#clearAndContinue").onclick = clearAndContinue;
$("#cancelCapacity").onclick = cancelCapacityDecision;

function resetBasketDeckFan() {
  $("#basketDetailDeck").querySelectorAll(".deck-card").forEach((card) => {
    card.classList.remove("deck-preview", "deck-locked", "deck-inert");
    card.setAttribute("aria-pressed", "false");
  });
}

function previewBasketDeckCard(card) {
  if (basketLockedDeckPage !== null) return;
  resetBasketDeckFan();
  card.classList.add("deck-preview");
}

function toggleBasketDeckCard(card) {
  const page = Number(card.dataset.page);
  if (basketLockedDeckPage !== null && basketLockedDeckPage !== page) return;
  if (basketLockedDeckPage === page) {
    basketLockedDeckPage = null;
    resetBasketDeckFan();
    $("#basketDetailDeckHint").textContent = "已取消固定；轻移鼠标预览，点击一张可再次固定";
    return;
  }
  basketLockedDeckPage = page;
  $("#basketDetailDeck").querySelectorAll(".deck-card").forEach((row) => {
    const selected = Number(row.dataset.page) === page;
    row.classList.toggle("deck-locked", selected);
    row.classList.toggle("deck-inert", !selected);
    row.setAttribute("aria-pressed", String(selected));
  });
  $("#basketDetailDeckHint").textContent = `已固定第 ${page + 1} 张；其他牌保持不动，再点当前牌取消`;
}

function renderBasketArtworkDetail(item) {
  basketDetailItem = item;
  basketLockedDeckPage = null;
  showBasketPane("detail");
  $("#basketTitle").textContent = "采集篮 · 作品详情";
  $("#basketDetailTitle").textContent = item.title;
  $("#basketDetailWorkType").hidden = item.workType !== "ugoira";
  $("#basketDetailDesc").textContent = item.description;
  $("#basketDetailArtist").textContent = item.artist;
  $("#basketDetailSize").textContent = `${item.width} × ${item.height} px`;
  $("#basketDetailBookmarks").textContent = Number(item.bookmarks || 0).toLocaleString();
  $("#basketDetailDate").textContent = item.date;
  $("#basketDetailTags").innerHTML = (item.tags || []).map((tag) => `<span>#${esc(tag)}</span>`).join("");

  const visible = Math.min(item.pages, 4);
  const middle = (visible - 1) / 2;
  $("#basketDetailDeck").innerHTML = Array.from({ length: visible }, (_, page) => {
    const delta = page - middle;
    const angle = delta * 3.2;
    const lift = Math.abs(delta) * 4;
    const src = item.pageImages?.[page]?.regular || item.thumb || "";
    return `<button class="deck-card" data-page="${page}" style="--i:${page};--angle:${angle}deg;--lift:${lift}px" aria-label="第 ${page + 1} 张" aria-pressed="false"><img src="${esc(src)}" data-detail-artwork="${esc(item.id)}" data-detail-page="${page}" alt="${esc(item.title)} 第 ${page + 1} 张" loading="lazy" decoding="async"><span>${page + 1} / ${item.pages}</span></button>`;
  }).join("");
  installImageFallbacks($("#basketDetailDeck"));
  $("#basketDetailDeck").querySelectorAll(".deck-card").forEach((card) => {
    card.onmouseenter = () => previewBasketDeckCard(card);
    card.onmouseleave = () => { if (basketLockedDeckPage === null) resetBasketDeckFan(); };
    card.onclick = () => toggleBasketDeckCard(card);
  });
  $("#basketDetailDeckHint").textContent = item.pages > visible
    ? `预览前 ${visible} 张，共 ${item.pages} 张；点击一张固定，再点一次取消`
    : "轻移鼠标预览；点击一张固定，再点一次取消";
  renderCollectionWindowInto(item, $("#basketPages"), $("#basketPageMore"));
  $("#basketViewAll").hidden = item.pages <= visible;
  syncBasketHeader();
  syncBasketArtworkMeta();
}

async function openBatchCollection(id) {
  let item = selectedArtworks.get(id) || batchCandidateItems.find((candidate) => candidate.id === id);
  if (!item) return;
  if (detailController) detailController.abort();
  viewGeneration += 1;
  abortDetailRefreshes();
  detailController = new AbortController();
  const controller = detailController;
  const generation = viewGeneration;
  try {
    if (item.source === "pixiv" && (!item.pageImages || staleBasketPreviewIds.has(String(item.id)))) {
      $("#basketTitle").textContent = "正在加载合集详情…";
      item = await fetchJson(`/api/pixiv/artwork/${item.id}`, { signal: controller.signal }, 18000);
      if (controller !== detailController || generation !== viewGeneration) return;
      const candidateIndex = batchCandidateItems.findIndex((candidate) => candidate.id === item.id);
      if (candidateIndex >= 0) batchCandidateItems[candidateIndex] = item;
      if (selectedArtworkIds.has(item.id)) selectedArtworks.set(item.id, item);
      staleBasketPreviewIds.delete(String(item.id));
    }
    if (controller !== detailController || generation !== viewGeneration) return;
    activeArtworkId = item.id;
    currentDetailItem = item;
    currentDetailContext = {
      ...(batchCandidateContextByArtwork.get(item.id)
        || selectedContextByArtwork.get(item.id)
        || activeSearchContext),
    };
    collectionPageOffset = 0;
    renderBasketArtworkDetail(item);
    $("#basketPage").scrollTop = 0;
  } catch (error) {
    if (controller.signal.aborted) return;
    announceToast(error.message || "作品详情加载失败");
  } finally {
    if (controller === detailController) detailController = null;
  }
}

$("#openBasketPicker").onclick = () => {
  if (basketSelectionLocked || searchPending) return;
  if (batchCandidateItems.length) {
    openBasketArtworkPicker();
    openBasketPage();
    $("#basketPage").scrollTop = 0;
  } else {
    openSelectionBasket();
  }
};
$("#basketBack").onclick = () => {
  if (basketSelectionLocked) return;
  viewGeneration += 1;
  abortDetailRefreshes();
  if (detailController) detailController.abort();
  detailController = null;
  if (basketReturnMode === "detail") {
    basketDetailItem = null;
    basketLockedDeckPage = null;
    $("#basketDetailDeck").innerHTML = "";
    $("#basketPages").innerHTML = "";
    openBasketArtworkPicker();
    $("#basketPage").scrollTop = 0;
  }
  else showBatchDetail();
};
$("#selectAllPage").onclick = selectAllCurrentPage;
$("#clearPageSelection").onclick = clearAllCurrentPage;
$("#clearSelection").onclick = () => {
  if (basketSelectionLocked || searchPending) return;
  viewGeneration += 1;
  abortDetailRefreshes();
  if (detailController) detailController.abort();
  detailController = null;
  clearAllSelection();
  clearDetail();
  render();
};
$("#openBatch").onclick = openBatchHub;

$("#batchDownload").onclick = async () => {
  if (basketSelectionLocked || searchPending || singleDownloadPending) return;
  const groups = selectedGroups();
  if (!groups.length) {
    announceToast("请至少选择一张图片");
    return;
  }
  let plannedChunks;
  try {
    plannedChunks = planContextDownloadChunks(groups);
  } catch (error) {
    announceToast(error.message);
    return;
  }
  const button = $("#batchDownload");
  const taskOptions = {
    quality: $("#quality").value || "regular",
    saveRoot: $("#saveRoot").value.trim(),
    createFolder: $("#createFolder").checked,
    groupArtworks: Boolean($("#groupArtworks")?.checked),
  };
  const task = prepareBatchTask(plannedChunks, taskOptions);
  const chunks = task.remainingChunks;
  setDownloadButtonState(button, "准备保存…", true);
  setBasketSelectionLocked(true);
  announceToast("本次任务已锁定当前勾选；完成前不能修改采集篮。");
  showTaskDock("批量下载", "任务已锁定，正在准备保存…", 0);
  let activeChunkIndex = 0;
  try {
    for (let index = 0; index < chunks.length; index += 1) {
      activeChunkIndex = index;
      const chunk = chunks[index];
      setDownloadButtonState(button, `正在保存第 ${task.completedBatches + 1}/${task.totalBatches} 批…`, true);
      showTaskDock("批量下载", `第 ${task.completedBatches + 1}/${task.totalBatches} 批 · 已保存 ${task.savedCount} 张`, 0);
      const data = await fetchJson("/api/pixiv/batch-download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          groups: chunk.groups,
          ...taskOptions,
          context: chunk.context,
        }),
      }, 300000);
      task.savedCount += Array.isArray(data.saved) ? data.saved.length : chunk.pageCount;
      task.completedBatches += 1;
      task.remainingChunks = chunks.slice(index + 1);
    }
    resumableBatchTask = null;
    announceToast(`已保存 ${task.savedCount} 张图片，共 ${task.totalBatches} 批`);
    showTaskDock("批量下载完成", `已保存 ${task.savedCount} 张图片，共 ${task.totalBatches} 批`);
  } catch (error) {
    task.remainingChunks = chunks.slice(activeChunkIndex);
    resumableBatchTask = task;
    const prefix = task.savedCount ? `已保存 ${task.savedCount} 张；后续` : "批量下载";
    announceToast(`${prefix}失败：${error.message}。再次点击只继续剩余 ${task.remainingChunks.length} 批。`);
    showTaskDock("批量下载中断", `${prefix}失败：${error.message}；重试只继续剩余 ${task.remainingChunks.length} 批`, 8000);
  } finally {
    setBasketSelectionLocked(false);
    setDownloadButtonState(button, "下载已勾选图片", false);
  }
};

addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  if (document.querySelector("dialog[open]")) return;
  if (!$("#allViewer").hidden) {
    closeAllViewer();
    return;
  }
  if (basketPageOpen() && !basketSelectionLocked) $("#basketBack").click();
});

function updateFormatHint() {
  const quality = $("#quality").selectedOptions[0]?.textContent || "";
  const format = $("#format").selectedOptions[0]?.textContent || "";
  $("#qualityText").textContent = quality;
  $("#formatText").textContent = format;
  if (currentDetailItem?.workType === "ugoira") {
    $("#formatHint").textContent = `动图将保存为官方帧 ZIP，并附带帧延迟 JSON（${quality}）。超过 40MB 的超大动图会被拒绝。`;
  } else {
    $("#formatHint").textContent = quality ? `将按 ${quality}，${format} 保存。源格式不可转换时会保留原扩展名。` : "";
  }
}

$("#quality").onchange = updateFormatHint;
$("#format").onchange = updateFormatHint;
$("#searchForm").onsubmit = (event) => {
  event.preventDefault();
  search($("#tag").value, 1, readSearchFilters());
  scrollToResults();
};

cancelSearchButton.onclick = () => {
  if (!searchController) return;
  cancelSearchButton.disabled = true;
  $("#count").textContent = "正在停止搜索…";
  cancelActiveSearch();
};

$("#browseFolder").onclick = async () => {
  const button = $("#browseFolder");
  button.disabled = true;
  button.textContent = "等待选择…";
  try {
    let data;
    if (window.pywebview?.api?.select_folder) {
      data = await window.pywebview.api.select_folder();
    } else {
      data = await fetchJson("/api/system/select-folder", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ initial: $("#saveRoot").value }),
      }, 300000);
    }
    if (data.selected) {
      $("#saveRoot").value = data.selected;
      announceToast(`保存位置：${data.selected}`);
    } else if (data.cancelled) {
      announceToast("已取消目录选择");
    }
  } catch (error) {
    announceToast(error.message || "目录选择失败");
  } finally {
    button.disabled = false;
    button.textContent = "浏览…";
  }
};

$("#download").onclick = async () => {
  const item = selectedArtworks.get(activeArtworkId) || items.find((row) => row.id === activeArtworkId);
  if (!item || basketSelectionLocked || searchPending || singleDownloadPending) return;
  const sourceIndex = Math.max(0, items.findIndex((row) => row.id === item.id));
  const button = $("#download");
  singleDownloadPending = true;
  setDownloadButtonState(button, "正在保存…", true);
  showTaskDock("正在保存", "正在保存当前作品…", 0);
  syncSearchScopedControls();
  try {
    const request = downloadPayload(item, sourceIndex);
    const data = await fetchJson(request.endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request.body),
    }, request.timeout);
    announceToast(`已保存 ${data.saved.length} 张：${data.saved[0]}`);
    showTaskDock("保存完成", `已保存 ${data.saved.length} 张`);
  } catch (error) {
    announceToast(`保存失败：${error.message || "未知错误"}`);
    showTaskDock("保存失败", error.message || "未知错误", 8000);
  } finally {
    singleDownloadPending = false;
    button.textContent = downloadButtonLabel(currentDetailItem);
    syncSearchScopedControls();
  }
};

async function syncAuthStatus() {
  const generation = ++authStatusGeneration;
  try {
    const data = await fetchJson("/api/status", {}, 8000);
    if (generation !== authStatusGeneration) return;
    const logged = Boolean(data.loggedIn);
    const authorizationLost = lastKnownLoggedIn === true && !logged;
    lastKnownLoggedIn = logged;
    $("#mode").textContent = logged ? "PIXIV AUTHORIZED" : "PIXIV PUBLIC";
    $("#loginBtn").textContent = logged ? "Pixiv 已连接" : "登录 Pixiv";
    $("#authStateTitle").textContent = logged ? "当前：已连接" : "当前：未连接";
    $("#authStateText").textContent = logged ? "Pixiv 会话已保存在本机。" : "将在 MOKU 应用内打开 Pixiv 官方登录页面。";
    $("#authAction").textContent = logged ? "退出 Pixiv 账户" : "打开应用内登录窗口";
    $("#safety").querySelectorAll('option[value="r18"],option[value="all"]').forEach((option) => { option.disabled = !logged; });
    if (authorizationLost) handleAuthorizationLoss();
  } catch (error) {
    if (generation !== authStatusGeneration) return;
    $("#mode").textContent = "PIXIV OFFLINE";
    $("#authStateText").textContent = error.message || "暂时无法读取本机会话状态";
  }
}

const helpDialog = $("#helpDialog");
$("#helpBtn").onclick = () => helpDialog.showModal();
$("#networkCheck").onclick = async () => {
  const button = $("#networkCheck");
  button.disabled = true;
  button.textContent = "正在匿名检测…";
  $("#networkHeadline").textContent = "正在检查当前网络";
  $("#networkRoute").textContent = "当前路线：读取中";
  $("#networkGuidance").textContent = "正在分别测试 Pixiv 主站和图片线路，不会发送登录 Cookie。";
  $("#pixivCheck").textContent = "Pixiv 主站：检测中";
  $("#cdnCheck").textContent = "图片线路：检测中";
  try {
    const data = await fetchJson("/api/network/diagnose", {}, 20000);
    const summary = data.summary || {};
    $("#networkHeadline").textContent = summary.headline || "检测完成";
    $("#networkRoute").textContent = `当前路线：${summary.routeLabel || "未知"}`;
    $("#networkGuidance").textContent = summary.guidance || "请根据分项结果检查网络。";
    const checks = new Map((data.checks || []).map((row) => [row.name, row]));
    const errorLabels = {
      timeout: "连接超时",
      refused: "连接被拒绝",
      tls: "证书或 TLS 错误",
      http: "HTTP 响应异常",
      unavailable: "无法连接",
    };
    const formatCheck = (label, row) => row?.ok
      ? `${label}：可用${Number.isFinite(row.ms) ? `（${row.ms} ms）` : ""}`
      : `${label}：不可用（${errorLabels[row?.errorKind] || "无法连接"}）`;
    $("#pixivCheck").textContent = formatCheck("Pixiv 主站", checks.get("pixiv"));
    $("#cdnCheck").textContent = formatCheck("图片线路", checks.get("cdn"));
  } catch (error) {
    $("#networkHeadline").textContent = "网络检测未完成";
    $("#networkRoute").textContent = "当前路线：未知";
    $("#networkGuidance").textContent = error.message || "MOKU 暂时无法完成匿名网络检测。";
    $("#pixivCheck").textContent = "Pixiv 主站：未完成";
    $("#cdnCheck").textContent = "图片线路：未完成";
  } finally {
    button.disabled = false;
    button.textContent = "重新检测网络";
  }
};

const dialog = $("#loginDialog");
$("#loginBtn").onclick = async () => {
  dialog.showModal();
  await syncAuthStatus();
};
$("#authAction").onclick = async () => {
  const logged = $("#authAction").textContent.includes("退出");
  $("#authAction").disabled = true;
  $("#authStateText").textContent = logged ? "正在退出…" : "请在 MOKU 桌面登录窗口完成登录、验证码或 2FA；应用会实时监控状态…";
  let actionError = "";
  try {
    const remember = Boolean($("#rememberLogin").checked);
    let data;
    if (!window.pywebview?.api?.pixiv_login) {
      throw new Error("账户授权只在 MOKU 桌面版提供，请启动 MOKU.exe 后登录。");
    }
    data = logged
      ? await window.pywebview.api.pixiv_logout()
      : await window.pywebview.api.pixiv_login(remember);
    if (!data.ok) throw new Error(data.error || "授权失败");
  } catch (error) {
    actionError = error.message || "授权失败";
  } finally {
    await syncAuthStatus();
    if (actionError) $("#authStateText").textContent = actionError;
    $("#authAction").disabled = false;
  }
};
document.querySelectorAll(".dialog-close").forEach((button) => {
  button.onclick = () => button.closest("dialog")?.close();
});
document.querySelectorAll("dialog").forEach((modal) => {
  modal.onclick = (event) => {
    if (event.target === modal) modal.close();
  };
});

clearDetail();
grid.innerHTML = '<div class="empty-state"><b>准备就绪</b><p>输入标签后点击“开始寻找”。首屏不再自动连接 Pixiv。</p></div>';
$("#count").textContent = "等待搜索";
syncSearchScopedControls();

if ("requestIdleCallback" in window) {
  requestIdleCallback(() => syncAuthStatus(), { timeout: 2000 });
} else {
  setTimeout(() => syncAuthStatus(), 500);
}
